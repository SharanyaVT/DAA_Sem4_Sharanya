
def product_pair():
    L=[]
    n=int(input("enter lengtho f list:"))
    for i in range(0,n):
      L.append(int(input("Enter a number:")))
    print(L)
    max=0
    max2=0
    for i in L:
       if(i>max):
          max=i
    print(max)
    for i in L:
       if((i>max2) and (i<max)):
          print((i>max2),",",(max2<max))
          max2=i
          print(max2)
          
    print("------------")
    print(max2)
    print("product is=",max*max2)


product_pair()
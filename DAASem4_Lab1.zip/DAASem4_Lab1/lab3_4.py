def segregate_zero_one():
    L=[]
    n=int(input("enter lengtho f list:"))
    for i in range(0,n):
      L.append(int(input("Enter a number:")))
    print(L)
    count0=0
    count1=0
    for i in L:
        if i==0:
            count0=count0+1
        else:
            count1=count1+1
    L=[]
    for i in range(0,count0):
        L.append(0)
    for i in range(0,count1):
        L.append(1)
    print(L)
    
segregate_zero_one()
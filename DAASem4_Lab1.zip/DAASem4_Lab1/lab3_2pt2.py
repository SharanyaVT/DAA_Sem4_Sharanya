def product_pair():
    L = []
    n = int(input("Enter length of list: "))
    for i in range(n):
        L.append(int(input("Enter a number: ")))
    print("List:", L)

    max1 = max(L)
    max2 = 0  # Initialize max2 properly

    for i in L:
        if (i > max2) and (max2 < max1) and (max2 != max1):  # Ensure max2 is less than max1 and not equal to max1
            max2 = i

    print("Max 1:", max1)
    print("Max 2:", max2)
    print("------------")
    print("Product is:", max1 * max2)

product_pair()

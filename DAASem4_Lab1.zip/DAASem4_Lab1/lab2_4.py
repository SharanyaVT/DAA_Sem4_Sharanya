def inversion_count():
    L=[]
    n=int(input("enter length of list:"))
    for i in range(0,n):
      st=int(input(f"start time of activity {i+1}:"))
      et=int(input(f"start time of activity {i+1}:"))
      L.append((st,et))
    print(L)
    

inversion_count()
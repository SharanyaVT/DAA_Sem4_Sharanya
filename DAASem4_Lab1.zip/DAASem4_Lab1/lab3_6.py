def inversion_count():
    L=[]
    n=int(input("enter length of list:"))
    for i in range(0,n):
      L.append(int(input("Enter a number:")))
    print(L)
    K=int(input("Enter K value:"))
    pairlist=[]
    for i in range(0,n):
       for j in range(i,n):
          if(L[i]+L[j]==K):
             pairlist.append((L[i],L[j]))
    print(pairlist)

inversion_count()

def inversion_count2():
    L=[]
    n=int(input("enter length of list:"))
    for i in range(0,n):
      L.append(int(input("Enter a number:")))
    print(L)
    K=int(input("Enter K value:"))
    pairlist=[]
    for i in L:
       if((K-i) in L):
          pairlist.append((i,(K-i)))
       
    print(pairlist)

inversion_count2()


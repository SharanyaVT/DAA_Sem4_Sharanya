import timeit
import time
import matplotlib.pyplot as plt
class DAAlab1:
    def iterative_version(self,n):
        sum=0
        for i in range(1,n+1):
            sum=sum+i
        return sum
    
    def recursive_version(self,n):
        sum=0
        if(n==1):
            return 1
        else:
            return n+self.recursive_version(n-1)
    
obj=DAAlab1()
list_n=[]
list_time=[]
for i in range(1,20):
    list_n.append(i)
    start=time.time_ns()
    #print(start)
    print("sum=",obj.iterative_version(i))
    end=time.time_ns()
    #print(end)
    list_time.append(end-start)
plt.plot(list_n,list_time)
plt.show()
print(list_time)

list_n=[]
list_time=[]
for i in range(1,20):
    list_n.append(i)
    start=time.time_ns()
    #print(start)
    print("sum=",obj.recursive_version(i))
    end=time.time_ns()
    #print(end)
    list_time.append(end-start)
plt.plot(list_n,list_time)
plt.show()
print(list_time)
#print("sum of n numbers iter:",obj.iterative_version(5))
#print("sum of n numbers recur:",obj.recursive_version(5))

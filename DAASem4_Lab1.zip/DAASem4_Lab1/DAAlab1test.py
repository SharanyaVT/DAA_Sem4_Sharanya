import time
import matplotlib.pyplot as plt
class DAAlab1:
    def iterative_version(self,n):
        sum=0
        for i in range(1,n+1):
            sum=sum+i
        return sum
    
    def recursive_version(self,n):
        sum=0
        if(n==1):
            return 1
        else:
            return n+self.recursive_version(n-1)
    

obj=DAAlab1()
start=time.time_ns()
print("sum of n numbers iter:",obj.iterative_version(5))
end=time.time_ns()
print("t=",end-start)
#print("sum of n numbers recur:",obj.recursive_version(5))

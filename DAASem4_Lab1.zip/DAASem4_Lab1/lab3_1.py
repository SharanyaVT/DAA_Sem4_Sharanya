
def sum_pair():
    L=[]
    n=int(input("enter lengtho f list:"))
    for i in range(0,n):
      L.append(int(input("Enter a number:")))
    print(L)
    target=int(input("enter sum:"))
    result=[]
    count=0
    for i in L:
       num=target-i
       if(num in L)and(num not in result)and(num!=target/2):
          print("pair found=",i," and ",num)
          result.append(num)
          result.append(i)
          count=count+1
    if(count==0):
       print("pair not found")

sum_pair()


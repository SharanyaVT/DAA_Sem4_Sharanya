def inversion_count():
    L=[]
    n=int(input("enter length of list:"))
    for i in range(0,n):
      L.append(int(input("Enter a number:")))
    print(L)
    invList=[]
    for i in range(0,n):
       for j in range(i,n):
          if(L[i]>L[j]):
             invList.append((L[i],L[j]))
    print(invList)
    print("Total count of inversions:",len(invList))
             
inversion_count()